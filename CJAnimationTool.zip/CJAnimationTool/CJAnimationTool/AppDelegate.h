//
//  AppDelegate.h
//  CJAnimationTool
//
//  Created by JWCao on 2019/2/16.
//  Copyright © 2019年 曹纪伟. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

